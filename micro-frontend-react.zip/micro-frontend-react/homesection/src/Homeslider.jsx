import React from 'react';
import './home-banner.css';

function Homeslider() {
    return (
        <div class="Homesection">
            <div className='sec-sec'>
                <div className='right'>
                    <h6>Revolutionizing Pharmaceutical industry with advanced technology</h6>
                    <h1>
                        Holistically transform your organization to adapt to the future
                    </h1>
                    <p>Accelerate innovation, transform operations, and ensure compliance to drive better healthcare outcomes. The Pharmaceutical Industry is no different, as it has been impacted by changing consumer demand and highly volatile market conditions. These situations are forcing biopharma firms to reprioritize their ambitions towards delivering more
                        cost-effective and ensuring personalized treatments by leveraging technolog</p>

                </div>
                <div className='right'>
                    <img src="https://api.visionet.com/sites/default/files/2022-12/revolutionizing-pharmaceutical.jpg" />
                </div>
            </div>
        </div>
    );
}

export default Homeslider;