import React from "react";
import ReactDOM from "react-dom";
import Homebanner from "./homebanner";
import Homeimgtext from "./Homeimgtext";

import "./index.scss";

const App = () => (
  <div className="mt-10 text-3xl mx-auto max-w-6xl">
    <Homebanner />
    <Homeimgtext />
  </div>
);
ReactDOM.render(<App />, document.getElementById("app"));
