import React from 'react';
import './home-banner.css';

function Homebanner() {
    return (
        <div class="homebanner">
                <div className='homebanner'>
                    <img src="https://api.visionet.com/sites/default/files/2023-04/Banking%20and%20financial%20services.jpg" />
                </div>
        </div>
    );
}

export default Homebanner;