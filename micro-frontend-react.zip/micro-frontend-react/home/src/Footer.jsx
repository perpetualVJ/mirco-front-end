import React from 'react';
import './footer.css';

function Footer() {
  return (
    <div class="footer">
      <div className='footerinner'>
      <div class="menu1">
        <h1>Servies</h1>
      <ul>
        <li>Digital Commerce</li>
        <li>Application Integration</li>
        <li>Application Integration</li>
        <li>Contact Center Services</li>
      </ul>
      </div>
      <div class="menu1">
        <h1>Products</h1>
      <ul>
        <li>PartnerLinQ</li>
        <li>HauteLogic</li>
        <li>AtClose</li>
      </ul>
      </div>
      <div class="menu1">
        <h1>Quick Links</h1>
      <ul>
        <li>About Us</li>
        <li>Careers</li>
        <li>Contact Us</li>
        <li>DocVu.AI</li>
      </ul>
      </div>
      <div class="menu1">
      <h1>Others</h1>
      <ul>
        <li>Microsoft</li>
        <li>Sales Force</li>
        <li>HauteLogic</li>
      </ul>
      </div>
      </div>
      <div className='copy-right'>
        
      </div>
    </div>
  );
}

export default Footer;